from django.shortcuts import render, redirect
from django.contrib.auth import login as auth_login, update_session_auth_hash, authenticate, logout
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.utils.timezone import make_aware
from django.db.models import Q

from .models import *
from .forms import *
from datetime import date, datetime, timezone, time, timedelta
from . import functions
import os

##### Project is not suitable with android view #################

def home(request):
	# objects
	notes = NoteBookModel
	all_names = UserSignupForm.objects.all()
	
	# forms
	notebook_form = NoteBookModelForm()
	login_form = LoginForm()
	signup_form = SignupForm()

	# initialize user ownership
	note_copy_objects = None
	note_copy_count = 0
	note_count = 0
	note_objects = None
	community_posts_counts = 0
	request_acc_info = None
	found_notes = None
	found_notes_title = None

	# GET method
	if request.method == 'GET':
		all_names = UserSignupForm.objects.all()
		# forms
		notebook_form = NoteBookModelForm()
		login_form = LoginForm()
		signup_form = SignupForm()

		# searching notes
		# get user
		if request.GET.get('user_name_in_search') is not None:
			check_user = UserSignupForm.objects.filter(username = request.GET.get('user_name_in_search'))

			if check_user.count() == 0:
				user = None
			else:
				user = UserSignupForm.objects.get(username = request.GET.get('user_name_in_search'))		
		else :
			user = None
		# search notes by user_input
		if request.GET.get("search_by_title") != None:
			if 'search' in request.GET and request.GET.get('search_by_title') != "" :
				check_user = UserSignupForm.objects.filter(username = request.GET.get('user_name_in_search'))

				if check_user.count() != 0:
					found_notes = user.notebookmodel_set.filter(Q(note_title__icontains = request.GET.get('search_by_title')) | Q(note_body__icontains = request.GET.get('search_by_title'))).order_by("-id")
					found_notes_title = request.GET.get('search_by_title')
				else:
					messages.error(request, "User error in searching notes! Are u logged in?")
			else:
				found_notes = None
				found_notes_title = None

		if found_notes is not None:
				if found_notes.count() <= 0 :
					messages.error(request, "Can't find any notes about '%s'"%(found_notes_title))
		
		# search notes by time_range
		if request.GET.get('time_range') != "" and request.GET.get('time_range') is not None:
			start_date = datetime.now()
			start_date = make_aware(start_date)

			if(request.GET.get("time_range") == "last_an_hour"):
				target_date = start_date - timedelta(hours = 1)
			else:
				target_date = start_date - timedelta(days = int(request.GET.get("time_range")))

			# return founded notes
			if user is not None:
				found_notes = user.notebookmodel_set.filter(create_date__gte = target_date)
				found_notes_title = None
			
			# return a message if no notes found
			if not found_notes:
				messages.error(request, "Notes not found !")
		
		if request.session.get("current_user") is not None:
			user = UserSignupForm.objects.get(username = request.session.get("current_user"))
		
		if user is not None:
			user.is_logged_in = True
			user.save()
			# call fun
			u_ownership = functions.user_ownership(user)
			# get u_ownership
			note_copy_objects = u_ownership['note_copy_objects']
			note_copy_count = u_ownership['note_copy_count']
			note_count = u_ownership['note_count']
			note_objects = u_ownership['note_objects']
			community_posts_counts = u_ownership['community_posts_counts']

			# ellipse title 
			functions.ellipse_title(note_copy_objects)
			functions.ellipse_title(note_objects)
			
			#get current using user	
			request_acc_info = UserSignupForm.objects.get(username = user)
		
		# send to front view
		context = {
			'notebook_form': notebook_form,
			'note_objects': note_objects,
			'note_count': note_count,
			'note_copy_count': note_copy_count,
			'note_copy_objects': note_copy_objects,
			'found_notes_title': found_notes_title,
			'found_notes': found_notes,
			'login_form': login_form,
			'signup_form': signup_form,
			'all_names': all_names,
			'community_posts_counts': community_posts_counts,
			'user': user,
			'request_acc_info': request_acc_info
		}
		return render(request, 'home.html', context )

	# POST method
	if request.method == 'POST':
		# objects
		all_names = UserSignupForm.objects.all()

		# form
		notebook_form = NoteBookModelForm()
		login_form = LoginForm()
		signup_form = SignupForm()

		# get note_id and username
		note_id = request.POST.get('note_id')
		note_user = request.POST.get('note_user')

		# deleting checked_notes 
		if 'checked_items_delete' in request.POST:
			user = UserSignupForm.objects.get(username = request.POST.get("user_name_in_search"))
			checked_notes = notes.objects.filter(id__in = request.POST.getlist('selected_note'))
			checked_notes.delete()
			how_many_notes = len(request.POST.getlist("selected_note"))
			# show msg
			messages.success(request, "{} note(s) deleted.".format(how_many_notes))
	
		# note_edit
		if 'edit_done' in request.POST:
			get_user = UserSignupForm.objects.get(username = request.POST.get('owner_user'))
			get_note = NoteBookModel.objects.get(id = request.POST.get('share_note_id'))
			last_note_id = NoteBookModel.objects.last().id

			# delete the note
			get_note.delete()

			# remodify new note 
			get_note.id = last_note_id + 1
			get_note.user = get_user
			get_note.note_author = request.POST.get('note_author')
			get_note.note_title = request.POST.get('note_title')
			get_note.note_body = request.POST.get('note_body')
			get_note.create_date = datetime.now()
			get_note.posted_date = datetime.now()
			get_note.bg_color = request.POST.get('edit_bg_color')
			get_note.text_color = request.POST.get('edit_text_color')

			# note image
			if(request.FILES.get('edit_note_image')):
				get_note.note_image = request.FILES.get('edit_note_image')
			else :
				if get_note.note_image :
					get_note.note_image = get_note.note_image

			# delete note image
			if request.POST.get("remove_image") == "true" :
				get_note.note_image.delete();

			# save note for new info
			get_note.save()
			user = get_note.user

			# show success msg
			messages.success(request, "Note is edited.")

		# add_to_community
		if 'add_to_community' in request.POST:
			get_note = NoteBookModel.objects.get(id = request.POST.get('share_note_id'))
			if get_note.user.is_logged_in :
				if get_note:
					# check_note if already exist
					note = Community.community_posts.create(
														user = get_note.user,
														author = get_note.note_author,
														title = get_note.note_title,
														body = get_note.note_body,
														bg_color = get_note.bg_color,
														text_color = get_note.text_color,
														image = get_note.note_image,
														posted_date = get_note.posted_time
														)
					messages.success(request, "Note posted to Community ")
				else:
					messages.error(request, "Something was wrong !")
			else:
				messages.error(request, "You must login to Diary to share your note !")
			user = get_note.user

		# change user
		if 'send_user' in request.POST:
			user = UserSignupForm.objects.get(username = request.POST.get('user_name_'))
			old_user = UserSignupForm.objects.get(username = request.POST.get('current_user_name_'))
			if user.password1 == request.POST.get('user_pw'):
				user.is_logged_in = True
				old_user.is_logged_in = False
				messages.success(request, 'Welcome, %s'%(user.username))

				#get current using user	
				request_acc_info = UserSignupForm.objects.get(username = user)
				
			else:
				user = UserSignupForm.objects.get(username = request.POST.get('current_user_name_'))
				messages.error(request, 'Invalid password!')

			# save users
			user.save()
			old_user.save()

		# restore note
		if 'note_restore' in request.POST:
			user = UserSignupForm.objects.get(username = note_user)
			# get note to restore
			if(TrashModel.objects.filter(id = note_id).count() > 0):
				get_note = TrashModel.objects.get(id = note_id)
				# resotre a copy note to Note model
				note_copy = NoteBookModel.objects.create(
						user = get_note.user,
						note_author = get_note.note_author,
						note_title = get_note.note_title,
						note_body = get_note.note_body,
						create_date = datetime.now(),
						bg_color = get_note.bg_color,
						text_color = get_note.text_color,
						note_image = get_note.note_image
				)
				# delete the requested note
				get_note.delete()

				# show success message
				messages.success(request, 'Note restored!')
			else:
				pass

		# recycling note
		if 'recycle' in request.POST:
			user = UserSignupForm.objects.get(username = note_user)
			# get deleted note
			if(NoteBookModel.objects.filter(id = note_id).count() > 0):
				get_note = NoteBookModel.objects.get(id = note_id)
				# make a copy to trash table
				note_copy = TrashModel.objects.create(
						note_author = get_note.note_author,
						note_title = get_note.note_title,
						note_body = get_note.note_body,
						note_image = get_note.note_image,
						bg_color = get_note.bg_color,
						text_color = get_note.text_color,
						user = get_note.user
				)
				# delete the requested note
				get_note.delete()

				# show success message
				messages.success(request, 'Deleted note and it is stored in Trash .')
			else:
				pass

		# permant delete note
		if 'p_delete_note' in request.POST:
			# get note_user:
			user = UserSignupForm.objects.get(username = note_user)
			note = TrashModel.objects.filter(id = request.POST["note_id"])
			if note.count() > 0:
				note.delete()

				# show success message		
				messages.success(request, 'Note Deleted!')
			else:
				# return redirect('home')
				pass

		# delete note
		if 'delete_note' in request.POST:
			# get note_user
			user = UserSignupForm.objects.get(username = note_user)
			note = notes.objects.filter(id = request.POST.get("note_id"))
			if note.count() > 0:
				note.delete()

				# show success message 
				messages.success(request, 'Note Deleted!')
			else: 
				pass

		# mini form 
		if "submit_mini_info" in request.POST:
			user = UserSignupForm.objects.get(username = request.POST["requested_user_name"])
			# also change c_user name in community name
			r_user = Community_users.communtiy_users.get(username = request.POST['requested_user_name']) 
			
			# change name
			if "mini_form_text" in request.POST:
				if(request.POST["mini_form_text"] != "") :
					user.username = request.POST["mini_form_text"]
					r_user.username = request.POST["mini_form_text"]
					request.session["current_user"] = request.POST["mini_form_text"]
					r_user.save()
					user.save()

					# show success message
					messages.success(request, "Name changed successfully")
				else:
					# show error message
					messages.error(request, "Name can't be blank !")

			# change email
			if "mini_form_email" in request.POST:
				if(request.POST["mini_form_email"] != "") :
					user.email = request.POST["mini_form_email"];
					user.save()
					messages.success(request, "Email changed successfully")
				else:
					messages.error(request, "Email can't be blank!")

			# change password
			if "old_password" in request.POST:
				if user.password2 == request.POST["old_password"]:
					n_password_1 = request.POST["new_password1"]
					n_password_2 = request.POST["new_password2"]

					if n_password_1 == n_password_2:
						user.password1 = n_password_2
						user.password2 = n_password_2
						user.u_created_time = datetime.now()
						user.save()
						messages.success(request, 'Password Changed Successfully!')
					else:
						messages.error(request, 'New passwords are not same !')
				else:
					messages.error(request, 'Something Wrong. Please Try again !')
			
			# change image
			if "mini_form_Photo" in request.FILES:
				if request.FILES.get("mini_form_Photo") != "":
					user.profile_image = request.FILES.get("mini_form_Photo");
				else:
					if(user.profile_image):
						user.profile_image = user.profile_image
				user.save()
				messages.success(request, "Profile photo changed successfully")

			request_acc_info = UserSignupForm.objects.get(username = user.username)
		
		# note create
		if 'notebook_create' in request.POST:
			notebook_form = NoteBookModelForm(request.POST or None, request.FILES or None)
			
			if request.POST.get('user_id') is not None:
				user = UserSignupForm.objects.get(id = request.POST.get('user_id'))
			else:
				user = UserSignupForm.objects.get(username = request.session.get("current_user"))
			
			if request.POST['note_body'] is not "":
				if notebook_form.is_valid():
					new_note = notebook_form.save(commit = False)
					new_note.note_author = request.POST.get('username')
					new_note.note_title = request.POST.get('note_title')
					new_note.note_body = request.POST.get('note_body')
					new_note.bg_color = request.POST.get('bg_color')
					new_note.text_color = request.POST.get('text_color')
					new_note.note_image = request.FILES.get('note_image')
					new_note.user = user
					new_note.save()

					# clear data of the form after saving a note
					notebook_form = NoteBookModelForm()
					messages.success(request, 'Note created!')
				else:
					messages.error(request, 'Something was wrong!')
				
			else :
				messages.error(request, 'Empty note can\'t create!')
				
		# signup form
		if 'signup' in request.POST:
			signup_form = SignupForm(request.POST, request.FILES)
			if signup_form.is_valid():

				username = functions.check_user_name(signup_form)
				email = functions.check_user_email(signup_form)
				password = functions.check_user_pass(signup_form)

				if username == None:
					messages.error(request, "Username already exists!")
				elif password == None:
					messages.error(request, "Check password again!")
				else:
					user = signup_form.save(commit = False)
					user.username = username
					user.password1 = password
					user.password2 = password
					user.email = email
					user.profile_image = request.FILES.get('profile_image')
					user.is_logged_in = True
					user.save()
					request.session["current_user"] = user.username
					
					messages.success(request, 'User creation success.')
			else :
				messages.error(request, 'User creation fail !')

		# login form
		if 'login' in request.POST:
			login_form = LoginForm(request.POST)
			if login_form.is_valid():
				result = functions.check_user(login_form)
				if result is 'w_pw':
					messages.error(request, 'Invalid password!')
					user = None
				elif result is "user_does_not_exist":
					messages.error(request, 'User does not exist! ( Please create an account first )')
					user = None
				elif result is "logined":
					user = UserSignupForm.objects.get(username = request.POST.get("username"))
					user.is_logged_in = True
					user.save()
					request.session["current_user"] = user.username

					messages.success(request, 'Welcome %s, you successfully logged into Diary.'%(user.username))		
			else:
				messages.error(request, 'Invalid username or password')

		
	#### user u_ownership  ####
	if(type(user) == str) :
		user = UserSignupForm.objects.get(username = user)
	
	if user is not None:
		request.session.set_expiry((2400 * 30) * 7)
		u_ownership = functions.user_ownership(user)
		
		note_copy_objects = u_ownership['note_copy_objects']
		note_copy_count = u_ownership['note_copy_count']
		note_count = u_ownership['note_count']
		note_objects = u_ownership['note_objects']
		community_posts_counts = u_ownership['community_posts_counts']
		request_acc_info = UserSignupForm.objects.get(username = user.username)
		# ellipse title 
		functions.ellipse_title(note_copy_objects)
		functions.ellipse_title(note_objects)
			
	context = {
		'notebook_form': notebook_form,
		'note_objects': note_objects,
		'note_count': note_count,
		'note_copy_count': note_copy_count,
		'note_copy_objects': note_copy_objects,
		'found_notes': found_notes,
		'found_notes_title': found_notes_title,
		'login_form': login_form,
		'signup_form': signup_form,
		'all_names': all_names,
		'user': user,
		'community_posts_counts': community_posts_counts,
		'request_acc_info': request_acc_info
	}
	return render(request, 'home.html', context)

def community(request, user_id):
	users = Community_users.communtiy_users.all() 
	c_posts = Community.community_posts.all().order_by('-id')
	c_posts__count = Community.community_posts.all().count()
	post_comments = Comment.objects.all()
	comment_for_this_post = None
	selected_user = 0
	get_about_user = None
	get_about_user_posts = None
	get_about_user_posts_count = 0
	# get client user notes for  managenent
	u_posts = Community.community_posts.filter(user__username = request.session.get("current_user"))
	u_posts_count = u_posts.count()

	# get a client username for selection box change "You"
	client_user = request.session.get("current_user")

	user = UserSignupForm.objects.get(username = request.session.get("current_user"))

	# collect a name as a community memeber if not
	c_user = Community_users.communtiy_users.filter(username = user)
	if c_user.count() == 0 :
		c_user = Community_users.communtiy_users.create(username = user)

	if request.method == 'POST':
		if 'uploaded_user' in request.POST:
			get_about_user = UserSignupForm.objects.get(username = request.POST.get("uploaded_user"))
			get_about_user_posts = Community.community_posts.filter(user__username = request.POST.get('uploaded_user')).order_by("-id")
			get_about_user_posts_count = get_about_user_posts.count()
		if 'selected_user' and 'chosen_user' in request.POST:
			if request.POST.get('selected_user') is not "":
				selected_user = request.POST.get('selected_user')
			else:
				selected_user = 0
			if request.POST.get('chosen_user') == 'all':
				c_posts = Community.community_posts.all().order_by('-id')
				context = {
					'users': users,
					'c_posts': c_posts,
					'comment_for_this_post': comment_for_this_post,
					'post_comments': post_comments,
					'c_posts__count': c_posts__count,
					'selected_user': selected_user,
					'client_user': client_user,
					'u_posts': u_posts,
					'u_posts': u_posts,
					'u_posts_count': u_posts_count,
					'get_about_user': get_about_user,
					'get_about_user_posts': get_about_user_posts,
					'get_about_user_posts_count': get_about_user_posts_count
				}
				return render(request, 'community_base.html', context)

			user = UserSignupForm.objects.get(username = request.POST.get('chosen_user'))
			c_posts = user.community_set.all().order_by('-id')
			c_posts__count = user.community_set.all().count()

		if 'submit_comment' in request.POST:
			commented_post = request.POST.get('commented_post')
			commented_user = request.POST.get('commented_user')
			comment = request.POST.get('comment')

			comment_for_this_post = Comment.objects.filter(commented_post = commented_post).order_by('-id')
			c_posts = Community.community_posts.filter(id = commented_post)

			commented_user = UserSignupForm.objects.get(username = commented_user)
			commented_post = Community.community_posts.get(id = commented_post)
			new_comment = Comment.objects.create(
					commented_post = commented_post,
					commented_user = commented_user,
					comment = comment
				)
			
		if 'delete_c_note' in request.POST:
			post_pk = request.POST.get('post_pk')
			post_to_delete = Community.community_posts.filter(id = post_pk)
			if(post_to_delete.count() > 0):
				if(post_to_delete.delete()):
					messages.success(request, "Removed post from community.")
				else:
					messages.error(request, "Something Wrong !")
			else:
				pass
			

		if 'comment_of_post' in request.POST:
			post_pk = request.POST.get('post_pk')
			comment_for_this_post = Comment.objects.filter(commented_post = post_pk)
			c_posts = Community.community_posts.filter(id = post_pk)
			
	context = {
		'users': users,
		'c_posts': c_posts,
		'user': user,
		'post_comments': post_comments,
		'comment_for_this_post': comment_for_this_post,
		'c_posts__count': c_posts__count,
		'selected_user': selected_user,
		'client_user': client_user,
		'u_posts': u_posts,
		'u_posts_count': u_posts_count,
		'get_about_user': get_about_user,
		'get_about_user_posts': get_about_user_posts,
		'get_about_user_posts_count': get_about_user_posts_count
	}
	return render(request, 'community_base.html', context)

def logout(request, user_id):
	user = UserSignupForm.objects.get(id = user_id)
	if request.session.get("current_user") is not None:
		del request.session["current_user"]
	user.is_logged_in = False
	user.save()
	return redirect('home')
