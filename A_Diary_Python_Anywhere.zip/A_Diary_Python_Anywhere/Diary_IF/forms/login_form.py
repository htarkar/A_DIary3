from ..models import Login
from django import forms

# notebook form
class LoginForm(forms.ModelForm):
	class Meta:
		model = Login
		fields = ['username', 'password']
		widgets = {
			'password': forms.PasswordInput(),
		}

		labels = {
			'username': 'Enter Username',
			'password': 'Enter Password',	
		}

