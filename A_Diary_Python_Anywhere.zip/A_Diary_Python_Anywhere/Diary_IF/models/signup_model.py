from django.db import models
from .functions import user_profile_image_path

class UserSignupForm(models.Model):
	username = models.CharField(max_length = 40, blank = False)
	password1 = models.CharField(max_length = 20, blank = False)
	password2 = models.CharField(max_length = 20, blank = False)
	email = models.EmailField(max_length = 100, blank = False) 
	profile_image = models.ImageField(upload_to = user_profile_image_path, blank = True)
	u_created_time = models.DateTimeField(auto_now_add = True)
	is_logged_in = models.BooleanField(default = False)

	def __str__(self):
		return self.username