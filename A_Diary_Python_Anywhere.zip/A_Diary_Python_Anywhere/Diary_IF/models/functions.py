from datetime import date

def user_directory_path(instance, filename):
	file_extension = filename.split('.')[-1]
	return '{3}/{0}___({2}).{1}'.format(instance.note_author, file_extension, instance.note_title, date.today())

def user_directory_path_community(instance, filename):
	file_extension = filename.split('.')[-1]
	return '{3}/{0}___({2}).{1}'.format(instance.author, file_extension, instance.title, str(date.today() + "_community"))

def user_profile_image_path(instance, filename):
	file_extension = filename.split('.')[-1]
	return '{3}/{2}/{0}.{1}'.format(instance.username, file_extension, str(date.today()) + '__profile_image', 'profile_images')
