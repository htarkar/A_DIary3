from django.db import models
from .functions import user_directory_path
from .signup_model import UserSignupForm
# note model
class NoteBookModel(models.Model):
	user = models.ForeignKey(UserSignupForm, name = 'user', on_delete= models.CASCADE, default = None, blank = True, null = True)
	note_author = models.CharField(max_length = 30, default = 'Unknown', blank = False)
	note_title = models.CharField(max_length = 50, default = 'Untitled Note', blank = True)
	note_body = models.CharField(max_length = 5000, blank = False, null = False)
	note_image = models.ImageField(upload_to = user_directory_path, blank = True)
	bg_color = models.CharField(max_length = 70, blank = True)
	text_color = models.CharField(max_length = 70, blank = True)
	create_date = models.DateTimeField(auto_now_add = True)
	posted_time = models.DateTimeField(default = None, blank = True, null = True)

	def __str__(self):
		return self.note_title